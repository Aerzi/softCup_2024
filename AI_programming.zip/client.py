import json
import asyncio
import websockets


async def send_question():
    async with websockets.connect("ws://localhost:8765") as websocket:
        question = input("请输入您的问题: ")
        print("请选择生成类型:")
        print("输入1：逐步解释")
        print("输入2：选择逐步伪代码")
        method_choice = input("请输入您的选择: ")

        request = {
            "question": question,
            "method_choice": method_choice
        }

        await websocket.send(json.dumps(request))
        response = await websocket.recv()
        response_data = json.loads(response)
        result = response_data.get('result', "没有得到有效的响应")
        print("结果:", result)

asyncio.get_event_loop().run_until_complete(send_question())